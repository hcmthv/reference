﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace api.lib
{
    //AES (Advanced Encryption Standard)
    public class AesCryto
    {
    }
}
