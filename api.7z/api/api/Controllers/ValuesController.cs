﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using rsa = api.lib;

namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private void RsaCryto() {
            var cryptoServiceProvider = new RSACryptoServiceProvider(2048); // 4096 - The length of the key

            var privateKey = cryptoServiceProvider.ExportParameters(true); // Generate the private key
            var publicKey = cryptoServiceProvider.ExportParameters(false); // Generate the public key

            string publicKeyString = rsa.RsaCrypto.EncodeTo64(rsa.RsaCrypto.GetKeyString(publicKey));
            string privateKeyString = rsa.RsaCrypto.EncodeTo64(rsa.RsaCrypto.GetKeyString(privateKey));


            var privateKeya = rsa.RsaCryptoBase64.ExportPrivateKey(cryptoServiceProvider);
            var publickeya = rsa.RsaCryptoBase64.ExportPublicKeyToPEMFormat(cryptoServiceProvider);
            //byte[] certBytes = Convert.FromBase64String(publickeya).Replace("-----BEGIN PUBLIC KEY-----", "").Replace("-----END PUBLIC KEY-----", "");

            var privateKeya1 = rsa.RSAKeys.ExportPrivateKey(cryptoServiceProvider);
            var publickeya1 = rsa.RSAKeys.ExportPublicKey(cryptoServiceProvider);

            try
            {
                //Create a UnicodeEncoder to convert between byte array and string.
                UnicodeEncoding ByteConverter = new UnicodeEncoding();

                //Create byte arrays to hold original, encrypted, and decrypted data.
                byte[] dataToEncrypt = ByteConverter.GetBytes("Data to Encrypt");
                byte[] encryptedData;
                byte[] decryptedData;

                //Create a new instance of RSACryptoServiceProvider to generate
                //public and private key data.
                using (RSACryptoServiceProvider RSA = new RSACryptoServiceProvider())
                {

                    //Pass the data to ENCRYPT, the public key information 
                    //(using RSACryptoServiceProvider.ExportParameters(false),
                    //and a boolean flag specifying no OAEP padding.
                    encryptedData =  rsa.RsaCrypto.RSAEncrypt(dataToEncrypt, RSA.ExportParameters(false), false);
                    var l_decryptedData = Convert.ToBase64String(encryptedData);

                    //var bytesToEncrypt = Encoding.UTF8.GetBytes(textToEncrypt);
                    //Pass the data to DECRYPT, the private key information 
                    //(using RSACryptoServiceProvider.ExportParameters(true),
                    //and a boolean flag specifying no OAEP padding.
                    encryptedData = Convert.FromBase64String(l_decryptedData);
                    decryptedData = rsa.RsaCrypto.RSADecrypt(encryptedData, RSA.ExportParameters(true), false);

                    //Display the decrypted plaintext to the console. 
                    Console.WriteLine("Decrypted plaintext: {0}", ByteConverter.GetString(decryptedData));
                }
            }
            catch (ArgumentNullException)
            {
                //Catch this exception in case the encryption did
                //not succeed.
                Console.WriteLine("Encryption failed.");
            }

            Console.WriteLine("PUBLIC KEY:");
            Console.WriteLine(publicKeyString);
            Console.WriteLine("-------------------------------------------");

            Console.WriteLine("PRIVATE KEY:");
            Console.WriteLine(privateKeyString);
            Console.WriteLine("-------------------------------------------");

            string textToEncrypt = rsa.RsaCrypto.GenerateTestString();
            Console.WriteLine("TEXT TO ENCRYPT:");
            Console.WriteLine(textToEncrypt);
            Console.WriteLine("-------------------------------------------");

            string encryptedText = rsa.RsaCrypto.Encrypt(textToEncrypt, rsa.RsaCrypto.DecodeFrom64(publicKeyString)); // Public key encryption
          
            Console.WriteLine("ENCRYPTED TEXT:");
            Console.WriteLine(encryptedText);
            Console.WriteLine("-------------------------------------------");

            string decryptedText = rsa.RsaCrypto.Decrypt(encryptedText, rsa.RsaCrypto.DecodeFrom64(privateKeyString)); // Decryption with private key           

            Console.WriteLine("DECRYPTED TEXT:");
            Console.WriteLine(decryptedText);
        }
              
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            RsaCryto();
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
